@extends('layouts.admin-app')
@section('content')
<city></city>
@endsection