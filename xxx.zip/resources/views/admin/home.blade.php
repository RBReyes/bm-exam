@extends('layouts.admin-app')
@section('content')
<admin-home></admin-home>
@endsection