@extends('layouts.guest-app')
@section('content')

<guest-home></guest-home>
@endsection