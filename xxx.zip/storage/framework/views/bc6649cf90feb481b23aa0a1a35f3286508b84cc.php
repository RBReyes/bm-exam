<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Travelin Responsive HTML Admin Dashboard Template based on Bootstrap 5">
    <meta name="author" content="Travelin">
    <title>Japan Endless Beauty</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('jpn_eb/assets/vendors/core/core.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('jpn_eb/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('jpn_eb/assets/fonts/feather-font/css/iconfont.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('jpn_eb/assets/css/style.css')); ?>">
    <link rel="shortcut icon" href="../images/favicon.png" />
</head><?php /**PATH E:\bizmate\bizmate-exam\resources\views/layouts/admin-head.blade.php ENDPATH**/ ?>