
<?php $__env->startSection('content'); ?>
<admin-home></admin-home>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bizmate\bizmate-exam\resources\views/admin/home.blade.php ENDPATH**/ ?>