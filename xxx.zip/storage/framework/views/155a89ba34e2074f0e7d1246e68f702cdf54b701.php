<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="zxx">
<?php echo $__env->make('layouts.guest-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
        <div id="app">
            <div id="preloader">
                <div id="status"></div>
            </div>
            <?php echo $__env->make('layouts.guest-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="tet"></div>
            
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('layouts.guest-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="back-to-top">
                <a href="#"></a>
            </div>
            <div id="search1">
                <button type="button" class="close">×</button>
                <form>
                <input type="search" value="" placeholder="type keyword(s) here" />
                <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
        </div>
            <?php echo $__env->make('layouts.guest-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
   
</body>
</html><?php /**PATH E:\bizmate\bizmate-exam\resources\views/layouts/guest-app.blade.php ENDPATH**/ ?>