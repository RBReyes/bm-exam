<nav class="sidebar">
    <div class="sidebar-header">
        <a href="/admin" class="sidebar-brand">
        <img src="../jpn_eb/images/logo.png" alt="logo" class="w-75">
        </a>
        <div class="sidebar-toggler not-active">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div class="sidebar-body">
    <ul class="nav">
        <li class="nav-item">
            <a href="<?php echo e(route('admin.app-setting')); ?>" class="nav-link">
            <i class="link-icon" data-feather="settings"></i>
            <span class="link-title">App Settings</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.city')); ?>" class="nav-link">
            <i class="link-icon" data-feather="file"></i>
            <span class="link-title">Cities</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.category')); ?>" class="nav-link">
            <i class="link-icon" data-feather="type"></i>
            <span class="link-title">Categories</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.guideline')); ?>" class="nav-link">
            <i class="link-icon" data-feather="columns"></i>
            <span class="link-title">Trip Guidelines</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.todo')); ?>" class="nav-link">
            <i class="link-icon" data-feather="image"></i>
            <span class="link-title">Things To do</span>
            </a>
        </li>
        
        
    </ul>
    </div>
</nav><?php /**PATH E:\bizmate\bizmate-exam\resources\views/layouts/admin-sidebar.blade.php ENDPATH**/ ?>