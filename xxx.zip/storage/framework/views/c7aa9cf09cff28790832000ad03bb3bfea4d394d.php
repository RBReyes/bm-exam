
<?php $__env->startSection('content'); ?>
<thing-todo :_kes="<?php echo e($kes); ?>" :_plan="<?php echo e($plan); ?>" :_cat="<?php echo e($cat); ?>"></thing-todo>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bizmate\bizmate-exam\resources\views/guest/thing-to-do.blade.php ENDPATH**/ ?>