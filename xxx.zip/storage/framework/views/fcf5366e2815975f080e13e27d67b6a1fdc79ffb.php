
<?php $__env->startSection('content'); ?>
<guest-plan :_kes="<?php echo e($kes); ?>" :_plan="<?php echo e($plan); ?>"></guest-plan>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bizmate\bizmate-exam\resources\views/guest/plan.blade.php ENDPATH**/ ?>