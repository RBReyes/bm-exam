<template>
    <section class="banner pt-10 pb-0 overflow-hidden" style="background-image:url(/jpn_eb/images/testimonial.png);">
        <div class="container">
        <div class="banner-in">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4">
                    <div class="banner-content text-lg-start text-center">
                    <h4 class="theme mb-0">Explore Japan Beauty</h4>
                    <h1>Start Planning Your Dream Trip Today!</h1>
                    <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore
                    </p>
                    </div>
                </div>
                <div class="col-lg-6 mb-4">
                    <div class="banner-image">
                    <img src="/jpn_eb/images/travel.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
</template>