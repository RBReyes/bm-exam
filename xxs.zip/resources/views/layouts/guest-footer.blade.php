<footer class="pt-20 pb-4" style="background-image: url(../jpn_eb/images/background_pattern.png);">
    <div class="section-shape top-0" style="background-image: url(../jpn_eb/images/shape8.png);"></div>
    <div class="insta-main pb-10">
    </div>
    <div class="footer-copyright">
    <div class="container">
        <div class="copyright-inner rounded p-3 d-md-flex align-items-center justify-content-between">
            <div class="copyright-text">
                <p class="m-0 white">2022 Japan Endless Beauty.</p>
            </div>
            <div class="social-links">
                <ul>
                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    </div>
    <div id="particles-js"></div>
</footer>