@extends('layouts.admin-app')
@section('content')
<app-setting></app-setting>
@endsection