@extends('layouts.admin-app')
@section('content')
<category></category>
@endsection