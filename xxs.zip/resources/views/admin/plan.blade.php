@extends('layouts.admin-app')
@section('content')
<admin-plan></admin-plan>
@endsection