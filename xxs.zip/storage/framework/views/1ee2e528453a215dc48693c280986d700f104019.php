
<?php $__env->startSection('content'); ?>
<guest-todo :_kes="<?php echo e($kes); ?>" :_plan="<?php echo e($plan); ?>" :_cat="<?php echo e($cat); ?>"></guest-todo>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bizmate\bizmate-exam\resources\views/guest/to-do.blade.php ENDPATH**/ ?>