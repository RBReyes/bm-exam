
<?php $__env->startSection('content'); ?>

<guest-home></guest-home>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bizmate\bizmate-exam\resources\views/guest/home.blade.php ENDPATH**/ ?>