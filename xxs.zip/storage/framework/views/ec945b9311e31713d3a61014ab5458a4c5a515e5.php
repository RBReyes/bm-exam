<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Japan Endless Beauty</title>
    <link rel="shortcut icon" type="image/x-icon" href="/jpn_eb/images/favicon.png">
    <link href="<?php echo e(asset('jpn_eb/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('jpn_eb/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('jpn_eb/css/plugin.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('jpn_eb/fonts/line-icons.css')); ?>" type="text/css">
</head><?php /**PATH E:\bizmate\bizmate-exam\resources\views/layouts/guest-head.blade.php ENDPATH**/ ?>